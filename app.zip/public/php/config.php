<?php

define("KEY_TOKEN", "APR.wqc-354*");

?>