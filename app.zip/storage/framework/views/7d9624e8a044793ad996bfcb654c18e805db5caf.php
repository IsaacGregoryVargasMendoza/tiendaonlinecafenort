

<?php $__env->startSection('title'); ?>
Tienda Cafenort
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container-admin'); ?>
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <div class="col-8 mx-auto">
    <div class="card-body">
    <div class="text-center"><h4>Lista de Categorias</h4></div>
    <div class="text-end mb-2">
        <a class="btn btn-primary btn-sm"  data-bs-toggle="modal" data-bs-target="#modalRegistroCategoria">NUEVO</a>
        <a href="listaproductos" class="btn btn-secondary btn-sm">CANCELAR</a>
    </div>
    <table id="datatable" class="table table-striped">
        <thead class="table-dark">
            <th scope="col">ID</th>
            <th class="text-center" scope="col">Nombre</th>
            <th class="text-center" scope="col">Acciones</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tipoproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoproducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($tipoproducto->id); ?></td>
                <td class="text-center"><?php echo e($tipoproducto->descripcionTipoProducto); ?></td>
                <td class="text-center">
                    <form action="<?php echo e(route('categorias.destroy',$tipoproducto->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <!-- <button type="button" class="btn text-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalEditarTipoProducto<?php echo e($tipoproducto->id); ?>"><i class="fa fa-solid fa-pen"></i></button> -->
                        <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modalEditarTipoProducto<?php echo e($tipoproducto->id); ?>">Editar</button>
                        <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                    </form>
                </td>
                <!-- Ventana modal para Edicion de Categorias -->
                <div class="modal fade" id="modalEditarTipoProducto<?php echo e($tipoproducto->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="">
                                <div class="text-center bg-info pt-3 pb-1"><h4 id="exampleModalLabel">Editar Categoria</h5></div>
                            </div>
                            <form action="/categorias/<?php echo e($tipoproducto->id); ?>" class="" method="POST" enctype="multipart/form-data" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="modal-body d-grid gap-1 col-10 mx-auto">
                                    <label for="descripcionTipoProducto" class="formulariolabel">Nombre</label>
                                    <input type="text" id="descripcionTipoProducto" name="descripcionTipoProducto" class="form-control text-uppercase" tabindex="1" autocomplete="off" maxlength="150" value="<?php echo e($tipoproducto->descripcionTipoProducto); ?>">
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" tabindex="2">Cancelar</button>
                                    <button type="submit" class="btn btn-primary" tabindex="3">Guardar Cambios</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    </div>

    <!-- Ventana modal para registro de Categorias -->
    <div class="modal fade" id="modalRegistroCategoria" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="">
                    <div class="text-center bg-info pt-3 pb-1"><h4 id="exampleModalLabel">Nueva Categoria</h5></div>
                </div>
                <form action="/categorias" class="" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body d-grid gap-1 col-10 mx-auto">
                        <!-- Grupo Nombre -->
                        <label for="descripcion" class="formulariolabel text-start">Nombre</label>
                        <input type="text" id="descripcion" name="descripcion" class="form-control" tabindex="1" autocomplete="off" maxlength="100">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal" tabindex="2">Cancelar</button>
                        <button type="submit" class="btn btn-primary btn-sm" tabindex="3">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Ventana modal para Edicion de Categorias -->
    <div class="modal fade" id="modalEditarCategoria" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="">
                    <div class="text-center bg-info pt-3 pb-1"><h4 id="exampleModalLabel">Editar Categoria</h5></div>
                </div>
                <form action="/categorias" class="" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body d-grid gap-1 col-10 mx-auto">
                        <!-- Grupo ID -->
                        <label for="id" class="formulariolabel">ID</label>
                        <input type="text" id="id" name="id" class="form-control" tabindex="1" autocomplete="off" maxlength="100">

                        <!-- Grupo Nombre -->
                        <label for="descripcion" class="formulariolabel">Nombre</label>
                        <input type="text" id="descripcion" name="descripcion" class="form-control" tabindex="1" autocomplete="off" maxlength="100">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" tabindex="2">Cancelar</button>
                        <button type="submit" class="btn btn-primary" tabindex="3">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script src=""></script>
<script>
    $(document).ready(function () {
        $('#datatable').DataTable({
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.12.1/i18n/es-ES.json"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u839948428/domains/devesoft.tech/public_html/resources/views/categoria/listar.blade.php ENDPATH**/ ?>