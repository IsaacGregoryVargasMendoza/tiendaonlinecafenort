<!-- Navbar & Carousel Start -->
<div class="container-fluid position-relative p-0">
        <nav class="navbar navbar-expand-lg navbar-dark px-5 py-3 py-lg-0" style="background-color: #091E3E;">
            <a href="index.html" class="navbar-brand p-0">
                <h1 class="m-0"><!-- <i class="fa fa-user-tie me-2"></i> -->DeveSoft</h1>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto py-0">
                    <a href="index.html" class="nav-item nav-link active">Home</a>
                    <a href="#" class="nav-item nav-link">Nosotros</a>
                    <a href="catalogo" class="nav-item nav-link">Catalogo</a>
                    <a href="#" class="nav-item nav-link">Servicios</a>
                    <a href="#" class="nav-item nav-link">Contáctanos</a>
                </div>
                <butaton type="button" class="btn text-primary ms-3" data-bs-toggle="modal"
                    data-bs-target="#searchModal"><i class="fa fa-search"></i></butaton>
                <a href="https://htmlcodex.com/startup-company-website-template"
                    class="btn btn-primary py-2 px-4 ms-3">Log In</a>
            </div>
        </nav>        
    </div>
    <!-- Navbar & Carousel End --><?php /**PATH C:\Users\HP\Desktop\devesoft\tiendaonlinecafenort\resources\views/partials/navbar.blade.php ENDPATH**/ ?>