

<?php $__env->startSection('title'); ?>
Tienda Cafenort
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container-admin'); ?>
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <div class="card shadow-sm col-12 mx-auto">
    <div class="card-body">
    <div class="text-center"><h4>Lista de Clientes</h4></div>
    <div class="text-end mb-1">
        <a class="btn btn-primary btn-sm"  data-bs-toggle="modal" data-bs-target="#modalRegistroCliente">NUEVO</a>
    </div>
    <table id="datatable" class="table table-striped mt-4">
        <thead class="table-dark">
            <th scope="col">ID</th>
            <th class="text-start" scope="col">Dni/Ruc<br>Denominacion</th>
            <th class="text-start" scope="col">Direccion</th>
            <th class="text-center" scope="col">Celular</th>
            <th class="text-start" scope="col">Correo</th>
            <th class="text-center" scope="col">Accion</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cliente->id); ?></td>
                <td class="text-start"><?php echo e($cliente->dniCliente); ?><br><?php echo e($cliente->nombreCliente); ?></td>
                <td class="text-start"><?php echo e($cliente->direccionCliente); ?></td>
                <td class="text-center"><?php echo e($cliente->celularCliente); ?></td>
                <td class="text-start"><?php echo e($cliente->correoCliente); ?></td>
                <td class="text-center">
                    <form action="<?php echo e(route('clientes.destroy',$cliente->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <!-- <a data-bs-toggle="modal" data-bs-target="#modalEditarCliente<?php echo e($cliente->id); ?>" class="btn text-dark btn-sm"><i class="fa fa-solid fa-pen"></i></a> -->
                        <div class="d-grid gap-2 d-md-block">
                            <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modalEditarCliente<?php echo e($cliente->id); ?>">Editar</button>
                            <button type="submit" class="btn btn-danger btn-sm">Borrar</button>
                        </div>
                    </form>
                </td>
                <!-- Ventana modal para Edicion de Clientes -->
                <div class="modal fade" id="modalEditarCliente<?php echo e($cliente->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="">
                                <div class="text-center bg-success text-white pt-3 pb-1"><h4 id="exampleModalLabel">Editar Cliente</h5></div>
                            </div>
                            <form action="/clientes/<?php echo e($cliente->id); ?>" class="" method="POST" enctype="multipart/form-data" autocomplete="off">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="modal-body col-10 mx-auto text-start">
                                    <!-- Grupo Nombre -->
                                    <label for="dniCliente<?php echo e($cliente->id); ?>" class="formulariolabel">DNI/RUC</label>
                                    <input type="text" id="dniCliente<?php echo e($cliente->id); ?>" name="dniCliente<?php echo e($cliente->id); ?>" class="form-control" tabindex="1" autocomplete="off" maxlength="11" value="<?php echo e($cliente->dniCliente); ?>">
                                    
                                    <div class="text-end">
                                        <button type="button" class="btn btn-outline-success btn-sm" onclick="buscarCliente()">Buscar</button>
                                    </div>

                                    <label for="nombreCliente<?php echo e($cliente->id); ?>" class="formulariolabel">Denominacion</label>
                                    <input type="text" id="nombreCliente<?php echo e($cliente->id); ?>" name="nombreCliente<?php echo e($cliente->id); ?>" class="form-control" tabindex="1" autocomplete="off" maxlength="150" value="<?php echo e($cliente->nombreCliente); ?>">
                                    
                                    <label for="direccionCliente<?php echo e($cliente->id); ?>" class="formulariolabel">Direccion</label>
                                    <input type="text" id="direccionCliente<?php echo e($cliente->id); ?>" name="direccionCliente<?php echo e($cliente->id); ?>" class="form-control" tabindex="2" autocomplete="off" maxlength="150" value="<?php echo e($cliente->direccionCliente); ?>">

                                    <label for="celularCliente<?php echo e($cliente->id); ?>" class="formulariolabel">Celular</label>
                                    <input type="number" id="celularCliente<?php echo e($cliente->id); ?>" name="celularCliente<?php echo e($cliente->id); ?>" class="form-control" tabindex="3" autocomplete="off" maxlength="12" value="<?php echo e($cliente->celularCliente); ?>">

                                    <label for="correoCliente<?php echo e($cliente->id); ?>" class="formulariolabel">Correo</label>
                                    <input type="text" id="correoCliente<?php echo e($cliente->id); ?>" name="correoCliente<?php echo e($cliente->id); ?>" class="form-control" tabindex="4" autocomplete="off" maxlength="150" value="<?php echo e($cliente->correoCliente); ?>">
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" tabindex="5">Cancelar</button>
                                    <button type="submit" class="btn btn-success" tabindex="6">Guardar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    </div>

    <!-- Ventana modal para registro de Clientes -->
    <div class="modal fade" id="modalRegistroCliente" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="">
                    <div class="text-center bg-success text-white pt-3 pb-1"><h4 id="exampleModalLabel">Nuevo Cliente</h5></div>
                </div>
                <form action="/clientes" class="" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body col-10 mx-auto text-start">
                        <!-- Grupo Nombre -->
                        <label for="dniCliente" class="formulariolabel">DNI/RUC</label>
                        <input type="text" id="dniCliente" name="dniCliente" class="form-control" tabindex="1" autocomplete="off" maxlength="11" value="">
                        
                        <div class="text-end">
                            <button type="button" class="btn btn-outline-success btn-sm" onclick="buscarCliente()">Buscar</button>
                        </div>

                        <label for="nombreCliente" class="formulariolabel">Denominacion</label>
                        <input type="text" id="nombreCliente" name="nombreCliente" class="form-control" tabindex="2" autocomplete="off" maxlength="150" value="">
                        
                        <label for="direccionCliente" class="formulariolabel">Direccion</label>
                        <input type="text" id="direccionCliente" name="direccionCliente" class="form-control" tabindex="3" autocomplete="off" maxlength="150" value="">

                        <label for="celularCliente" class="formulariolabel">Celular</label>
                        <input type="text" id="celularCliente" name="celularCliente" class="form-control" tabindex="4" autocomplete="off" maxlength="12" value="">

                        <label for="correoCliente" class="formulariolabel">Correo</label>
                        <input type="email" id="correoCliente" name="correoCliente" class="form-control" tabindex="5" autocomplete="off" maxlength="150" value="">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal" tabindex="6">Cancelar</button>
                        <button type="submit" class="btn btn-success btn-sm" tabindex="7">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script src="/js/validar.js"></script>
<script>
    $(document).ready(function () {
        $('#datatable').DataTable({
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.12.1/i18n/es-ES.json"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\devesoft\tiendaonlinecafenort\resources\views/cliente/listar.blade.php ENDPATH**/ ?>