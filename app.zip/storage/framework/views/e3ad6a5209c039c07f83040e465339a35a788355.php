

<?php $__env->startSection('title'); ?>
Tienda Cafenort
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container-admin'); ?>
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <div class="col-12 mx-auto">
        <div class="card-body">
            <div class="text-center"><h4>Lista de Ventas</h4></div>
                <table id="datatable" class="table table-striped mt-4">
                    <thead class="table-success">
                        <th scope="col">ID</th>
                        <th scope="col">Fecha Venta</th>
                        <th scope="col">Cliente</th>
                        <th class="text-center" scope="col">Serie</th>
                        <th class="text-center" scope="col">Subtotal</th>
                        <th class="text-center" scope="col">IGV</th>
                        <th class="text-end" scope="col">Total</th>
                        <th class="text-end" scope="col">Acciones</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($venta->id); ?></td>
                            <td class="text-start"><?php echo e($venta->fechaVenta); ?></td>
                            <td class="text-start"><?php echo e($venta->denominacionCliente); ?></td>
                            <td class="text-center"><?php echo e($venta->serieVenta); ?> - <?php echo e($venta->numeroSerieVenta); ?></td>
                            <td class="text-end">S/.<?php echo e(number_format($venta->totalVenta*0.18,2,'.',',')); ?></td>
                            <td class="text-end">S/.<?php echo e(number_format($venta->totalVenta*0.82,2,'.',',')); ?></td>
                            <td class="text-end">S/.<?php echo e(number_format($venta->totalVenta,2,'.',',')); ?></td>
                            <td class="text-center">
                                <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modalVer<?php echo e($venta->id); ?>" onclick="prueba(<?php echo $venta->id;?>)">Ver</button>
                            </td>
                        </tr>
                        <!-- Ventana modal para Edicion de Categorias -->
                        <div class="modal fade" id="modalVer<?php echo e($venta->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="">
                                        <div class="text-center bg-info pt-3 pb-1"><h4 id="exampleModalLabel">Detalle Venta</h4></div>
                                    </div>
                                    <div id="contenido-modal<?php echo e($venta->id); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script src=""></script>
<script>
    $(document).ready(function () {
        $('#datatable').DataTable({
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.12.1/i18n/es-ES.json"
            }
        });
    });

    async function prueba(id){
        document.getElementById("contenido-modal"+id).innerHTML = `<th></th>`
        const response = await fetch("http://localhost:8000/api/listadetalleventa/"+id,{method:'GET', headers: { 'Content-Type': 'application/json' }})
        console.log(await response.json())

        document.getElementById("contenido-modal"+id).innerHTML = `<table id="datatable" class="table table-striped mt-4">
            <thead class="table-hover">
                <th scope="col">Codigo</th>
                <th scope="col">Producto</th>
                <th class="text-center" scope="col">U. Med</th>
                <th class="text-end" scope="col">P. Uni</th>
                <th class="text-end" scope="col">Cantidad</th>
                <th class="text-end" scope="col">Total</th>
            </thead>
            <tbody id="tbody">
            </tbody>
        </table>`
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u839948428/domains/devesoft.tech/public_html/resources/views/venta/listar.blade.php ENDPATH**/ ?>