

<?php $__env->startSection('title'); ?>
Producto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container-admin'); ?>
<div class="">
<div class="text-center"><h5>Editar Producto</h5></div>

<form action="/actualizarproducto/<?php echo e($producto->id); ?>" class="" method="POST" enctype="multipart/form-data" autocomplete="off">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <?php
        $imagen = $producto->imagenProducto;

        if(!file_exists($imagen)){
            $imagen = "imagenes/no_imagen.png";
        }
    ?>
    <div class="column">
    <div class="card shadow-sm col-11 mx-auto">
        <div class="card-body bg-light">
            <div class="row">
                <div class="col-5 mx-auto text-start">
                    <!-- Grupo Codigo -->
                    <label for="codigo" class="formulariolabel">Codigo</label>
                    <input type="text" id="codigo" name="codigo" class="form-control form-control-sm" tabindex="1" autocomplete="off" value ="<?php echo e($producto->codigoProducto); ?>" maxlength="10" readonly>

                    <!-- Grupo Nombre -->
                    <label for="nombre" class="formulariolabel">Nombre</label>
                    <input type="text" id="nombre" name="nombre" class="form-control form-control-sm" tabindex="2" autocomplete="off" value="<?php echo e($producto->nombreProducto); ?>" maxlength="100">

                    <!-- Grupo Detalles -->
                    <label for="detalle" class="formulariolabel">Detalles</label>
                    <textarea class="form-control form-control-sm" name="detalle" id="detalle" cols="30" rows="6" tabindex="3" autocomplete="off"><?php echo e($producto->descripcionProducto); ?></textarea>

                    <!-- Grupo Stock -->
                    <label for="stock" class="formulariolabel">Stock</label>
                    <input type="text" id="stock" name="stock" class="form-control form-control-sm" tabindex="4" autocomplete="off" value="<?php echo e($producto->stockProducto); ?>">

                    <!-- Grupo Precio -->
                    <label for="precio" class="formulariolabel">Precio</label>
                    <input type="text" id="precio" name="precio" class="form-control form-control-sm" tabindex="5" autocomplete="off" value="<?php echo e($producto->precioProducto); ?>">

                    <!-- Grupo Unidad de Medida -->
                    <label for="unidadmedida" class="formulariolabel">Unidad de medida</label>
                    <select name="unidadmedida" id="unidadmedida" class="form-control form-control-sm" aria-label="Default select example" tabindex="6"> 
                        <?php if($producto->unidadMedida == "UNIDAD"): ?>
                        <option selected="true" value="UNIDAD">UNIDAD</option>
                        <option value="GRAMO">GRAMO</option>
                        <option value="KILO">KILO</option>
                        <option value="CIENTO">CIENTO</option>
                        <option value="MILLAR">MILLAR</option>
                        <option value="LITRO">LITRO</option>
                        <?php elseif($producto->unidadMedida == "GRAMO"): ?>
                        <option value="UNIDAD">UNIDAD</option>
                        <option selected="true" value="GRAMO">GRAMO</option>
                        <option value="KILO">KILO</option>
                        <option value="CIENTO">CIENTO</option>
                        <option value="MILLAR">MILLAR</option>
                        <option value="LITRO">LITRO</option>
                        <?php elseif($producto->unidadMedida == "KILO"): ?>
                        <option value="UNIDAD">UNIDAD</option>
                        <option value="GRAMO">GRAMO</option>
                        <option selected="true" value="KILO">KILO</option>
                        <option value="CIENTO">CIENTO</option>
                        <option value="MILLAR">MILLAR</option>
                        <option value="LITRO">LITRO</option>
                        <?php elseif($producto->unidadMedida == "CIENTO"): ?>
                        <option value="UNIDAD">UNIDAD</option>
                        <option value="GRAMO">GRAMO</option>
                        <option value="KILO">KILO</option>
                        <option selected="true" value="CIENTO">CIENTO</option>
                        <option value="MILLAR">MILLAR</option>
                        <option value="LITRO">LITRO</option>
                        <?php elseif($producto->unidadMedida == "MILLAR"): ?>
                        <option value="UNIDAD">UNIDAD</option>
                        <option value="GRAMO">GRAMO</option>
                        <option value="KILO">KILO</option>
                        <option value="CIENTO">CIENTO</option>
                        <option value="MILLAR">MILLAR</option>
                        <option value="LITRO">LITRO</option>
                        <?php else: ?>
                        <option value="UNIDAD">UNIDAD</option>
                        <option value="GRAMO">GRAMO</option>
                        <option value="KILO">KILO</option>
                        <option value="CIENTO">CIENTO</option>
                        <option value="MILLAR">MILLAR</option>
                        <option selected="true" value="LITRO">LITRO</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="col-5 mx-auto text-start">
                    <!-- Grupo Tipo Producto -->
                    <label for="tipoproducto" class="formulariolabel">Tipo de Producto</label>
                    <select name="tipoproducto" class="form-control form-control-sm" aria-label="Default select example" tabindex="7"> 
                        <?php $__currentLoopData = $tipoproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoproducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($tipoproducto->id == $producto->tipoproducto->id): ?>
                                <option selected="true" value="<?php echo e($tipoproducto->id); ?>"><?php echo e($tipoproducto->descripcionTipoProducto); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($tipoproducto->id); ?>"><?php echo e($tipoproducto->descripcionTipoProducto); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <!-- Grupo esta Visible -->
                    <label for="visible" class="formulariolabel">Visible</label>
                    <select name="visible" class="form-control form-control-sm" aria-label="Default select example" tabindex="8">
                        <?php if($producto->visibleProducto == 1): ?>
                            <option selected="true" value="1">SI</option>
                            <option value="0">NO</option>
                        <?php else: ?>
                            <option value="1">SI</option>
                            <option selected="true" value="0">NO</option>
                        <?php endif; ?>
                    </select>

                    <!-- Grupo Producto -->
                    <label for="imagenproducto" class="formulariolabel">Imagen Producto</label>
                    <input type="file" id="imagenproducto" name="imagenproducto" class="form-control form-control-sm" tabindex="9" autocomplete="off" accept="image/*" onchange="mostrarImagen()">
                    
                    <!-- Imagen del Producto -->
                    <div class="card shadow-sm">
                        <img id="imagen" class="img-catalogo-formulario" src="/<?php echo e($imagen); ?>" alt="Imagen producto" >
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="d-grid gap-1 col-5 mx-auto mt-3">
                    <button class="btn btn-primary btn-sm" type="submit" tabindex="10">Guardar</button>
                    <a href="<?php echo e(route('listaproductos.index')); ?>" class="btn btn-secondary btn-sm" type="button" tabindex="11">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/js/formulario.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u839948428/domains/devesoft.tech/public_html/resources/views/producto/editar.blade.php ENDPATH**/ ?>