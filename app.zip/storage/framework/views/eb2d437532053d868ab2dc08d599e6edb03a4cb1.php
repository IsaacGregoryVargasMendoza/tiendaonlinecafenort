

<?php $__env->startSection('title'); ?>
Tienda Cafenort
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container-admin'); ?>
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <div class="col-12 mx-auto">
        <div class="card-body">
            <div class="text-center"><h4>Lista de Productos</h4></div>
                <div class="text-end mb-2">
                    <a href="<?php echo e(route('catalogo.create')); ?>" class="btn btn-primary btn-sm">NUEVO</a>
                    <a href="categorias" class="btn btn-secondary btn-sm">CATEGORIAS</a>
                </div>
                <table id="datatable" class="table table-striped mt-4">
                    <thead class="table-dark">
                        <th scope="col">ID</th>
                        <th scope="col">Codigo</th>
                        <th scope="col">Nombre</th>
                        <th class="text-center" scope="col">Categoria</th>
                        <th class="text-end" scope="col">Stock</th>
                        <th class="text-center" scope="col">U. Medida</th>
                        <th class="text-end" scope="col">Precio</th>
                        <th class="text-center" scope="col">Acciones</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($producto->id); ?></td>
                            <td class="text-uppercase"><?php echo e($producto->codigoProducto); ?></td>
                            <td class="text-uppercase"><?php echo e($producto->nombreProducto); ?></td>
                            <td class="text-center"><?php echo e($producto->tipoproducto->descripcionTipoProducto); ?></td>
                            <td class="text-end"><?php echo e($producto->stockProducto); ?></td>
                            <td class="text-center text-uppercase"><?php echo e($producto->unidadMedida); ?></td>
                            <td class="text-end">S/.<?php echo e(number_format($producto->precioProducto,2,'.',',')); ?></td>
                            <td class="text-center">
                                <form action="<?php echo e(route('listaproductos.destroy',$producto->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a href="<?php echo e(route ('listaproductos.edit',$producto->id)); ?>" class="btn btn-info btn-sm">Editar</a>
                                    <button type="submit" class="btn btn-danger btn-sm">Borrar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script src=""></script>
<script>
    $(document).ready(function () {
        $('#datatable').DataTable({
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.12.1/i18n/es-ES.json"
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u839948428/domains/devesoft.tech/public_html/resources/views/producto/listar.blade.php ENDPATH**/ ?>